#include "nb-samples.h"

void print_decimal_result(NB_HANDLE connection)
{
    check_error(connection);

    while (nb_fetch_row(connection) == NB_OK)
    {
        std::cout << "===\n";

        NBValue name, v;
        int fieldcount = nb_field_count(connection);
        for (int i = 0; i < fieldcount; i++)
        {
            nb_field_name_utf8(connection, i, &name);
            nb_field_value_utf8(connection, i, &v);

            std::cout << name << ": " << v << std::endl;
        }
    }
    check_error(connection);
}

int main()
{
	const char16_t* host = u"127.0.0.1";
	const int port = 3020;
	const char16_t* username = u"TESTUSER";
	const char16_t* userpass = u"1234";

	NB_HANDLE connection = nb_connect(host, port, username, userpass);

    nb_execute_sql(connection, u"DROP TABLE IF EXISTS decimal_demo_table");
	nb_execute_sql(connection, uR"(
        CREATE TABLE decimal_demo_table(
            id_     INT, 
            float_  FLOAT, 
            real_   REAL, 
            double_ DOUBLE, 
            dec_    DECIMAL(10,2), 
            num_    NUMERIC(10,2));
    )");

	nb_execute_sql(connection, u"INSERT INTO decimal_demo_table VALUES (1, 0.0, 0.0, 0.0, 0.0, 0.0);");
	
	for (int i = 0; i < 100; i++ )
	{
		nb_execute_sql(connection, uR"(
            UPDATE decimal_demo_table SET 
                float_  = float_+0.01, 
                real_   = real_+0.01, 
                double_ = double_+0.01, 
                dec_    = dec_+0.01, 
                num_    = num_+0.01 
            WHERE id_ = 1;)");

 	}
    nb_execute_sql(connection, u"SELECT * FROM decimal_demo_table;");
    print_decimal_result(connection);

	nb_disconnect(connection);
    return 0;
}
