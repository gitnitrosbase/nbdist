#include "nb-samples.h"

int main()
{
    NB_HANDLE connection = nb_connect( u"127.0.0.1", 3020, u"TESTUSER", u"1234" );
    check_error( connection );

    nb_execute_sql( connection, uR"(
        SELECT TOP 10 * FROM person
        BEGIN TRAN
        UPDATE person SET age = age + 1 WHERE id = 'person1'
        ROLLBACK TRAN
    )" );

    for ( int i = 0;; i++ )
    {
        std::cout << "\nQuery part " << i << std::endl;
        check_error( connection );
        int type, count;
        nb_get_change_info( connection, &type, &count );

        if ( type == SQL_QUERY_SELECT )
        {
            while ( nb_fetch_row( connection ) == NB_OK )
            {
                std::cout << "\n------------------------------\n";

                NBValue name, v;
                int fieldcount = nb_field_count( connection );
                for ( int i = 0; i < fieldcount; i++ )
                {
                    nb_field_name_utf8( connection, i, &name );
                    nb_field_value_utf8( connection, i, &v );
                    std::cout << name << ": " << v << std::endl;
                }
            }
        }
        else if( type == SQL_QUERY_INSERT || type == SQL_QUERY_UPDATE || type == SQL_QUERY_DELETE )
        {
            std::cout << "Affected rows: " << count << std::endl;
        }

        if ( !nb_nextresult( connection ) )
            break;
    };


    nb_disconnect( connection );
    return 0;
}
