#include "nb-samples.h"

int main()
{
    NB_HANDLE connection = nb_connect( u"127.0.0.1", 3020, u"TESTUSER", u"1234" );
    check_error( connection );
    
    std::cout << "List of db tables\n";
    nb_get_tableslist( connection );
    print_query_result( connection );

    std::cout << "\nList of fields of table 'person'\n";
    nb_get_tableschema( connection, u"Person", 6 );
    print_query_result( connection );

    std::cout << "\nList of indexes'\n";
    nb_get_indexschema( connection );
    print_query_result( connection );

    std::cout << "\nList of indexes in the table 'person'\n";
    nb_get_tableindexschema(connection, u"Person", 6);
    print_query_result(connection);

    nb_disconnect( connection );
    return 0;
}
