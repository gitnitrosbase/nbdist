#include "nb-samples.h"

void PrintInsertedRowsCount( NB_HANDLE connection )
{
    check_error( connection );
	int type, count; 
    nb_get_change_info( connection, &type, &count );
    std::cout << "  Count = " << count << '\r';
}

int main()
{
    NB_HANDLE connection = nb_connect( u"127.0.0.1", 3020, u"TESTUSER", u"1234" );
    check_error( connection );

    nb_execute_sql( connection, u"DROP TABLE IF EXISTS Table1; CREATE TABLE Table1 ( Id INT primary key, Value INT )" );

    NB_HANDLE queryhandle;
    nb_prepare_query( connection, u"INSERT INTO Table1 VALUES(?,?)", &queryhandle );
    check_error( connection );

    nb_start_bulk( connection );

    for ( int i = 0; i < 1'000'000; i++ )
    {
        nb_start_execute_prep( connection, queryhandle );
        nb_write_param_int( connection, i );
        nb_write_param_int( connection, i );
        nb_execute_prep( connection );
        if ( ( i % 10000 ) == 9999 )
        {
            nb_get_bulk_info( connection );
            PrintInsertedRowsCount( connection );
        }
    }

    nb_stop_bulk( connection );
    PrintInsertedRowsCount( connection );
    std::cout << std::endl;

    nb_execute_sql( connection, u"SELECT TOP 10 * FROM Table1" );
    check_error( connection );

    while ( nb_fetch_row( connection ) == NB_OK )
    {
        std::cout << "\n------------------------------\n\n";

        NBValue name, v;
        int fieldcount = nb_field_count( connection );
        for ( int i = 0; i < fieldcount; i++ )
        {
            nb_field_name_utf8( connection, i, &name );
            nb_field_value_utf8( connection, i, &v );
            std::cout << name << ": " << v << std::endl;
        }
    }
    check_error( connection );
    nb_close_prepared_query( connection, queryhandle );
    nb_disconnect( connection );
    return 0;
}
