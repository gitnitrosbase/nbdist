#include "nb-samples.h"

int main()
{
	const char16_t* host = u"127.0.0.1";
	const int       port = 3020;
	const char16_t* username = u"TESTUSER";
	const char16_t* userpass = u"1234";

    NBValue v;

	// Opening a connection
	NB_HANDLE connection = nb_connect(host, port, username, userpass);

	// Executing a query
    nb_execute_sql(connection, u"SELECT COUNT(*) FROM person");

	// Printing the query result
    if (nb_fetch_row(connection) == NB_OK) {
        nb_field_value_utf8(connection, 0, &v);
        std::cout << "count is " << v << std::endl;
    } else
        std::cout << "Some error"<< std::endl;

	// Closing the connection
	nb_disconnect(connection);

    return 0;
}
