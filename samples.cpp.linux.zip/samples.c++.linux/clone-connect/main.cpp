#define _CRT_SECURE_NO_WARNINGS
#include "nb-samples.h"

using namespace std;

int main()
{
    const char16_t* host = u"127.0.0.1"; 
    const int       port = 3020;
    const char16_t* user = u"TESTUSER"; 
    const char16_t* pass = u"1234";

    NB_HANDLE connection_pool[10]; // [0] - seed; [1..9] - clones

    // Allocate the connection pool
    for (int i = 0; i < 10; i++) {
        if (i == 0) 
            connection_pool[i] = nb_connect(host, port, user, pass);    // seed
        else 
            connection_pool[i] = nb_clone_connect(connection_pool[0]);  // clone
        check_error(connection_pool[i]);
        std::cout << "Connection " << i << " has been connected" << std::endl;
    }

    // Run SQL queries on the connection pool 
    for (int i = 0; i < 10; i++)
    {
        int AgeMin = i * 10, AgeMax = AgeMin + 10;
        char s[1000];

        // Get data
        int len = sprintf(s, R"(
            select age, COUNT(age) number from person 
                where %d <= age and age < %d  
                group by age order by age
            )", AgeMin, AgeMax);
        nb_execute_sql_utf8(connection_pool[i], s, len);
        check_error(connection_pool[i]);
    }

    // Print the result
    for (int i = 0; i < 10; i++)
    {
        int AgeMin = i * 10, AgeMax = AgeMin + 10;

        std::cout << "  Connection " << i << " is monitoring ages [";
        std::cout << AgeMin << ":" << AgeMax - 1 << "]" << endl;
        
        int k;
        for (k = 0; nb_fetch_row(connection_pool[i]) == NB_OK; k++)
        {
            NB_HANDLE conn = connection_pool[i];
            NBValue name, v;

            int fieldcount = nb_field_count(conn);
            for (int i = 0; i < fieldcount; i++)
            {
                nb_field_name_utf8(conn, i, &name);
                nb_field_value_utf8(conn, i, &v);
                std::cout << name << ": " << v << "    ";
                if (i == 1) std::cout << std::endl;
            }

        }
        check_error(connection_pool[i]);
        if (k == 0)
            cout << "No records found" << endl;
    }

    // Release the connection pool
    for (int i = 9; i >= 0; i--) {
        nb_disconnect(connection_pool[i]);
        std::cout << "Connection " << i << " has been disconnected" << std::endl;
    }
}


