#include "nb-samples.h"

int main()
{
    NB_HANDLE connection = nb_connect( u"127.0.0.1", 3020, u"TESTUSER", u"1234" );
    check_error( connection );

    //prepare query
    NB_HANDLE queryhandle;
    nb_prepare_query( connection, u"select * from person where age > ? and age < ? and name = ?", &queryhandle );
    check_error( connection );

    //run prepared query
    nb_start_execute_prep( connection, queryhandle );
    
    nb_write_param_int( connection, 29 );
    nb_write_param_int( connection, 31 );
    //nb_write_param_str( connection, (char16_t *)u"Mercedez", 8 );
    nb_start_param_blob(connection, NB_DATA_U16STRING);
    nb_write_blob_part(connection, (void*)u"Merce", 10);
    nb_write_blob_part(connection, (void*)u"dez", 6);
    nb_end_param_blob(connection);

    nb_execute_prep( connection );

    check_error( connection );

    while ( nb_fetch_row( connection ) == NB_OK )
    {
        std::cout << "\n------------------------------\n";

        NBValue name, v;
        int fieldcount = nb_field_count( connection );
        for ( int i = 0; i < fieldcount; i++ )
        {
            nb_field_name_utf8( connection, i, &name );
            nb_field_value_utf8( connection, i, &v );
            std::cout << name << ": " << v << std::endl;
        }
    }
    check_error( connection );
    nb_close_prepared_query( connection, queryhandle );
    nb_disconnect( connection );
    return 0;
}
