#include "nb-samples.h"

int main()
{
	NB_HANDLE connection1 = nb_connect(u"127.0.0.1", 3020, u"USER1", u"1234");
    NB_HANDLE connection2 = nb_connect(u"127.0.0.1", 3020, u"USER2", u"9876");

    std::cout << "\nUnder connection1 create and fill in a new temporary table - #tmp_table\n";
    nb_execute_sql(connection1, u"CREATE TABLE #tmp_table(id INT, first_value VARCHAR(10), second_value VARCHAR(20));");
	nb_execute_sql(connection1, u"INSERT INTO #tmp_table(id, first_value, second_value) VALUES (0,'value1', 'value1');");
    nb_execute_sql(connection1, u"INSERT INTO #tmp_table(id, first_value, second_value) VALUES (1,'value2', 'value2');");

    std::cout << "\nSELECT * FROM #tmp_table via connection1\n";
    nb_execute_sql(connection1, u"SELECT * FROM #tmp_table;");
    print_query_result(connection1);

    std::cout << "\nSELECT * FROM #tmp_table via connection2\n";
    nb_execute_sql(connection2, u"SELECT * FROM #tmp_table;");
    print_query_result(connection2);

    nb_disconnect(connection1);
	nb_disconnect(connection2);

    return 0;
}
