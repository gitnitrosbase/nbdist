#include "nb-samples.h"

int main()
{
	const char16_t* host = u"127.0.0.1";
	const int       port = 3020;
	const char16_t* username = u"TESTUSER";
	const char16_t* userpass = u"1234";

	NB_HANDLE connection = nb_connect(host, port, username, userpass);

    nb_execute_sql(connection, u"DROP TABLE IF EXISTS identity_demo_table;");
    nb_execute_sql(connection, u"CREATE TABLE identity_demo_table (id_ int IDENTITY(1,1), text_ VARCHAR(10));");

    nb_execute_sql(connection, u"INSERT INTO identity_demo_table VALUES ('text1');");
    nb_execute_sql(connection, u"INSERT INTO identity_demo_table VALUES ('text2');");
    nb_execute_sql(connection, u"INSERT INTO identity_demo_table VALUES ('text3');");
    nb_execute_sql(connection, u"INSERT INTO identity_demo_table VALUES ('text4');");
    nb_execute_sql(connection, u"INSERT INTO identity_demo_table VALUES ('text5');");
    nb_execute_sql(connection, u"INSERT INTO identity_demo_table VALUES ('text6');");

	nb_execute_sql(connection, u"SELECT * FROM identity_demo_table;");
    print_query_result(connection);

	nb_disconnect(connection);
    return 0;
}
